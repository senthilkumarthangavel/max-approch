export const validate = (json, index, state) => {
    
    let a = state.q2, b = state.q1, q = 0, r = 0;
    if (index > 0) {
        a = state && state.data && state.data[index - 1] && state.data[index - 1]['b'] ? state.data[index - 1]['b'] : state.q2;
        b = state && state.data && state.data[index - 1] && state.data[index - 1]['r'] ? state.data[index - 1]['r'] : state.q1;
        q = getQuotient(a, b);
        r = getReminder(a, b);
    }

    
    console.log('value_index', index)       
    console.log("result ", json);
    console.log("state ", state);
    console.log("a ", a);
    console.log("b ", b);
    console.log("q ", q);
    console.log("r ", r);

    //condition1 - first operand check
    const operand_one = json.fn;
    if (operand_one !== 'equal'){
        return "String must have equal!";
    }

    //condition2 - quotient check
    const q1_num = json.arg[0].num;
    if (parseInt(q1_num) !== parseInt(a)){
        return "Dividend is not correct!";
    }

    
    //add all conditions here
    
    
    
    
    
    
    
    //console.log('quotient', quotient);
    //console.log('remainder', remainder);
    // const operand_one = enterValue.fn;
    // const q1_num_arr = enterValue.arg
    // const q1_num = enterValue.arg[0].num;
    // const q2_num = enterValue.arg[1].arg[0].arg[0].num;
    //const q3_num = enterValue.arg[1].arg[0].arg[1].num;
    //const operand_two = enterValue.arg[1].arg[0].fn;
    // const  operand_three = enterValue.arg[1].fn;

    //console.log('enterValue', enterValue);
    // console.log('q1_num_arr', q1_num_arr);
    //console.log('q1_num', q1_num);
    // console.log('q2_num', q2_num);
    //console.log('q3_num', q3_num);
    // console.log('operand_one', operand_one);
    //  console.log('operand_two', operand_two);
    // console.log('operand_three', operand_three);
    
    return true;
};

export const getResultObject = (json, index, state, org_text) => {
    
    const q1_num = json.arg[0].num;
    const q2_num = json.arg[1].arg[0].arg[0].num;
    const q3_num = json.arg[1].arg[0].arg[1].num;
    const reminder = getReminder(q1_num, q2_num);

    let Obj = {
        'a': q1_num,
        'b': q2_num,
        'q': q3_num,
        'r': reminder,
        org_text
    };

    let data = state && state.data ? state.data : {};
    data[index] = Obj;

    return data;
}

const getReminder = (q1, q2) =>  {

    let remainder_num;

    if (q2 > q1) {
        remainder_num = (Math.floor(q2 % q1));
    } else {
        remainder_num = 0;
    }

    return remainder_num;
}

const getQuotient = (q1, q2) =>  {

    let quotient_num;

    if (q2 > q1) {
        quotient_num = (Math.floor(q2 / q1));
    } else {
        quotient_num = 0;
    }

    return quotient_num;
}