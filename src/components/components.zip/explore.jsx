import React, { Component } from 'react';
import { MathFieldComponent } from 'react-mathlive';
import MathLive from 'mathlive';
import { validate, getResultObject } from './explore/hcf/validation';

class MultiMath extends Component {

    constructor() {
        super();
        this.ast = undefined;
        this.get_index = undefined;
        this.targetRef = React.createRef();
        this.state = {
            count: [1],
            add: false,
            q1: 135,
            q2: 225,
            quotient: '',
            set_one: {},
            ast_fn: '',
            data: {}

        }
    }

    componentDidUpdate() {

        const target = this.targetRef.current;

        const value_index = target.getAttribute('data-value');  //index value
        this.get_index = value_index;
        //console.log('value_index', value_index)                 //index value

        if (target) {
            console.log('target', target);
            const mathField = MathLive.makeMathField(target);
            console.log('mathField', mathField);

            mathField.$setConfig({
                virtualKeyboardMode: 'onfocus',
                virtualKeyboards: 'all',
                onBlur: mathfield => {
                    try {
                        const ast = MathLive.latexToAST(mathfield.$text());
                        this.ast = ast;
                        
                        //validate HCF
                        let valid = validate(ast, this.get_index, this.state);
                        
                        console.log("valid ", valid);
                        
                        //valid => true dont hide + and green in textbox 
                        //valid => otherwise hide +, red in textbox and show error message under textbox
                        if (valid === true) { 

                        } else {

                        }

                        document.getElementById(
                            'output'
                        ).innerHTML = JSON.stringify(
                            mathJsonToMathjs(ast, {}).eval()
                        );
                        
                        // document.getElementById('output').innerHTML = JSON.stringify(ast);
                    } catch (e) {
                        document.getElementById('output').innerHTML = '😕';
                    }
                }
            })
        }
        function applySuperscriptAsPower(mjs, mathJson, config) {
            let result = mjs;
            if (
                typeof mathJson === 'object' &&
                mathJson.sup !== undefined
            ) {
                result = new window.math.expression.node.FunctionNode(
                    'pow',
                    [result, mathJsonToMathjs(mathJson.sup, config)]
                );
            }
            return result;
        }

        function getMathjsArgs(mathJson, config) {
            let result = [];
            if (Array.isArray(mathJson.arg)) {
                for (
                    let index = 0;
                    index < mathJson.arg.length;
                    index++
                ) {
                    result.push(
                        mathJsonToMathjs(mathJson.arg[index], config)
                    );
                }
            } else {
                result = [mathJsonToMathjs(mathJson.arg, config)];
            }
            return result;
        }
        /**
         * Return an array of arguments, with the sub if present as the last argument.
         */
        function getMathjsArgsWithSub(mathJson, config) {
            const result = getMathjsArgs(mathJson, config);
            if (mathJson.sub !== undefined) {
                result.push(mathJsonToMathjs(mathJson.sub, config));
            }

            return result;
        }

        /**
         * Return a mathjs node tree corresponding to the MathjSON object
         * @param {Object.<string,any>} mathJson
         */
        function mathJsonToMathjs(mathJson, config) {
            let result;
            if (mathJson === undefined) return undefined;

            if (
                typeof mathJson === 'number' ||
                mathJson.num !== undefined
            ) {
                let n =
                    typeof mathJson === 'number'
                        ? mathJson
                        : mathJson.num;

                // Convert to BigNum if required
                if (config.number === 'BigNumber')
                    n = window.math.bignumber(n);

                result = new window.math.expression.node.ConstantNode(
                    n
                );

                // Apply the superscript as an operation
                result = applySuperscriptAsPower(
                    result,
                    mathJson,
                    config
                );
            } else if (
                typeof mathJson === 'string' ||
                mathJson.sym !== undefined
            ) {
                const BUILT_IN_CONSTANTS = {
                    π: window.math.pi,
                    τ: window.math.tau, // GREEK SMALL LETTER TAU
                    ℯ: window.math.e, // ℯ SCRIPT SMALL E
                    ⅇ: window.math.e, // ⅇ DOUBLE-STRUCK ITALIC SMALL E
                    e: window.math.e,
                    ϕ: window.math.phi, //  GREEK SMALL LETTER PHI
                    ⅈ: window.math.i, // ⅈ DOUBLE-STRUCK ITALIC SMALL I
                    ⅉ: window.math.i, // ⅉ DOUBLE-STRUCK ITALIC SMALL J
                    i: window.math.i, //
                };
                const symbol =
                    typeof mathJson === 'string'
                        ? mathJson
                        : mathJson.sym;
                if (BUILT_IN_CONSTANTS[symbol]) {
                    result = new window.math.expression.node.ConstantNode(
                        BUILT_IN_CONSTANTS[symbol]
                    );
                }
                result = applySuperscriptAsPower(
                    result,
                    mathJson,
                    config
                );
            } else if (mathJson.op !== undefined) {
                if (
                    mathJson.lhs !== undefined &&
                    mathJson.rhs !== undefined
                ) {
                    const OPERATOR_FUNCTIONS = {
                        '+': 'add',
                        '-': 'subtract',
                        '*': 'multiply',
                        '/': 'divide',
                        // '.*': 'dotMultiply',
                        // './': 'dotDivide',
                        '%': 'mod',
                        mod: 'mod',
                    };
                    const args = [
                        mathJsonToMathjs(mathJson.lhs, config),
                        mathJsonToMathjs(mathJson.rhs, config),
                    ];
                    result = new window.math.expression.node.OperatorNode(
                        mathJson.op,
                        OPERATOR_FUNCTIONS[mathJson.op],
                        args
                    );
                } else if (mathJson.rhs !== undefined) {
                    const UNARY_OPERATOR_FUNCTIONS = {
                        '-': 'unaryMinus',
                        '+': 'unaryPlus',
                        // '~': 'bitNot',
                        // 'not': 'not'
                    };
                    result = new window.math.expression.node.OperatorNode(
                        mathJson.op,
                        UNARY_OPERATOR_FUNCTIONS[mathJson.op],
                        [mathJsonToMathjs(mathJson.rhs, config)]
                    );
                }
            } else if (mathJson.fn) {
                if (
                    mathJson.fn === 'log' ||
                    (mathJson.fn === 'ln' &&
                        mathJson.fn.sub !== undefined)
                ) {
                    result = new window.math.expression.node.FunctionNode(
                        'log',
                        getMathjsArgsWithSub(mathJson, config)
                    );
                } else if (mathJson.fn === 'lb') {
                    const args = getMathjsArgs(mathJson, config);
                    args.push(
                        new window.math.expression.node.ConstantNode(
                            window.math.bignumber(2)
                        )
                    );
                    result = new window.math.expression.node.FunctionNode(
                        'log',
                        args
                    );
                } else if (mathJson.fn === 'lg') {
                    result = new window.math.expression.node.FunctionNode(
                        new window.math.expression.node.SymbolNode(
                            'log10'
                        ),
                        getMathjsArgs(mathJson, config)
                    );
                } else {
                    const fnName =
                        {
                            '+': 'add',
                            '-': 'subtract',
                            '*': 'multiply',
                            '/': 'divide',
                            randomReal: 'random',
                            randomInteger: 'randomInt',
                            Gamma: 'gamma',
                            Re: 're',
                            Im: 'im',
                            binom: 'composition',
                            ucorner: 'ceil',
                            lcorner: 'floor',
                            arccos: 'acos',
                            arcsin: 'asin',
                            arctan: 'atan',
                            arcosh: 'acosh',
                            arsinh: 'asinh',
                        }[mathJson.fn] || mathJson.fn;

                    result = new window.math.expression.node.FunctionNode(
                        fnName,
                        getMathjsArgs(mathJson, config)
                    );
                }
            } else if (mathJson.group) {
                result = applySuperscriptAsPower(
                    mathJsonToMathjs(mathJson.group, config),
                    mathJson,
                    config
                );
            }

            return result;
        }

    }



    staticCalc(q1, q2) {

        let quotient_num, remainder_num;

        if (q2 > q1) {
            quotient_num = (Math.floor(q2 / q1));
            remainder_num = (Math.floor(q2 % q1));

        }

        this.setState({
            quotient: quotient_num
        })
        //console.log('quo', this.state.quotient)
    }


    validation(enterValue) {
        let get_index = this.get_index

        if (get_index === 1) {
            enterValue.arg[0].num = this.state.q2
        }
        return false
    }

    addQuestion = (e) => {

        //this.staticCalc(this.state.q1, this.state.q2);
        //const enterValue = this.ast;

        //this.validation(enterValue) ? console.log('test') : console.log('test1')


        //console.log('quotient', quotient);
        //console.log('remainder', remainder);
        // const operand_one = enterValue.fn;
        // const q1_num_arr = enterValue.arg
        // const q1_num = enterValue.arg[0].num;
        // const q2_num = enterValue.arg[1].arg[0].arg[0].num;
        //const q3_num = enterValue.arg[1].arg[0].arg[1].num;
        //const operand_two = enterValue.arg[1].arg[0].fn;
        // const  operand_three = enterValue.arg[1].fn;

        //console.log('enterValue', enterValue);
        // console.log('q1_num_arr', q1_num_arr);
        //console.log('q1_num', q1_num);
        // console.log('q2_num', q2_num);
        //console.log('q3_num', q3_num);
        // console.log('operand_one', operand_one);
        //  console.log('operand_two', operand_two);
        // console.log('operand_three', operand_three);



        let counter = this.state.count.concat(['']);
        let data = getResultObject(this.ast, this.get_index, this.state);
        this.setState({
            count: counter,
            add: (!this.state.add),
            data: data
        })

    }


    handleDelete = i => e => {
        e.preventDefault()
        let newarr = [
            ...this.state.count.slice(0, i),
            ...this.state.count.slice(i + 1)
        ]
        this.setState({
            count: newarr
        })
    }

    render() {
        const { count } = this.state
 console.log("this.state ", this.state);

        return (
            <div>

                <div className="App">
                    <p>Use Math editor for calculation </p>
                    {count.length > 0 && count !== 0 ? (count.slice(0, 4).map((count, index) => (

                        <div key={index} className="wrap-set">
                            <p>Step:&nbsp;{parseInt(`${index}`) + 1}</p>
                            <span className={'fieldwrap'} ref={this.targetRef} data-value={index}>{/*this.state.data[index]*/}</span>

                            {parseInt(index) + 1 === 1 ?
                                <><button onClick={this.addQuestion} className={'editor-plus btn btn-primary'}>+</button> </> :
                                <><button onClick={this.handleDelete(index)} className={'editor-plus sub btn btn-primary'}>-</button>
                                    <button onClick={this.addQuestion} className={'editor-plus btn btn-primary'}>+</button> </>}
                        </div>
                    ))) : null}

                    <pre id="output"></pre>

                </div>
            </div>
        );
    }

}
export default MultiMath;